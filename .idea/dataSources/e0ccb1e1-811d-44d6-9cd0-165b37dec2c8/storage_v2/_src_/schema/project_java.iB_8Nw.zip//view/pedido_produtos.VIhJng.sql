create definer = developer@`%` view pedido_produtos as
select `lo`.`numero_pedido` AS `numero_pedido`,
       `pr`.`id_produto`    AS `id_produto`,
       `pr`.`descricao`     AS `produto`,
       `se`.`descricao`     AS `secao`
from ((`project_java`.`lote` `lo` join `project_java`.`produtos` `pr`
       on ((`lo`.`id_produto` = `pr`.`id_produto`))) join `project_java`.`secao` `se`
      on ((`pr`.`secao` = `se`.`id_secao`)));

