create
    definer = admin@`%` procedure sp_movimentar_estoque(IN p_id_produto int, IN p_id_lote int, IN p_id_num_serie int,
                                                        IN p_id_endereco_origem int, IN p_id_endereco_destino int,
                                                        IN p_id_unidade_arm int, IN p_quantidade decimal(10, 3),
                                                        IN p_tipo_movimentacao varchar(20), IN p_id_documento int,
                                                        IN p_id_usuario int)
BEGIN
    DECLARE v_estoque_atual DECIMAL(10,3);

    -- Para movimentação de saída, verificar saldo
    IF p_tipo_movimentacao IN ('saida', 'picking', 'expedicao', 'transferencia') THEN
        SELECT quantidade
          INTO v_estoque_atual
          FROM inventario_estoque
         WHERE id_produto = p_id_produto
           AND id_endereco = p_id_endereco_origem
           AND (id_lote = p_id_lote OR (p_id_lote IS NULL AND id_lote IS NULL))
           AND id_unidade_arm = p_id_unidade_arm
         FOR UPDATE;

        IF v_estoque_atual < p_quantidade THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Saldo insuficiente para movimentação.';
        END IF;

        -- Atualiza estoque origem
        UPDATE inventario_estoque
           SET quantidade = quantidade - p_quantidade, data_atualizacao = NOW()
         WHERE id_produto = p_id_produto
           AND id_endereco = p_id_endereco_origem
           AND (id_lote = p_id_lote OR (p_id_lote IS NULL AND id_lote IS NULL))
           AND id_unidade_arm = p_id_unidade_arm;

    END IF;

    -- Atualiza/Injeta estoque destino
    IF p_tipo_movimentacao IN ('entrada', 'transferencia', 'recebimento', 'devolucao') THEN
        INSERT INTO inventario_estoque (
            id_produto, id_endereco, id_lote, id_unidade_arm, quantidade, status, data_atualizacao
        ) VALUES (
            p_id_produto, p_id_endereco_destino, p_id_lote, p_id_unidade_arm, p_quantidade, 'disponivel', NOW()
        )
        ON DUPLICATE KEY UPDATE
            quantidade = quantidade + p_quantidade,
            data_atualizacao = NOW();
    END IF;

    -- Registra movimentação, sempre!
    INSERT INTO movimentacao_estoque (
        data_movimentacao, id_produto, id_lote, id_num_serie, id_endereco_origem,
        id_endereco_destino, quantidade, tipo_movimentacao, id_documento, id_usuario
    )
    VALUES (
        NOW(), p_id_produto, p_id_lote, p_id_num_serie, p_id_endereco_origem,
        p_id_endereco_destino, p_quantidade, p_tipo_movimentacao, p_id_documento, p_id_usuario
    );
END;

