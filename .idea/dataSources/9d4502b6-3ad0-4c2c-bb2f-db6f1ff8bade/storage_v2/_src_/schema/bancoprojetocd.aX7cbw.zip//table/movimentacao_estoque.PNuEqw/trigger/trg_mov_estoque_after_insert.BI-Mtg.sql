create definer = admin@`%` trigger trg_mov_estoque_after_insert
    after insert
    on movimentacao_estoque
    for each row
BEGIN
    INSERT INTO auditoria (
        tabela, id_registro, acao, evento, data_evento, id_usuario, observacao
    ) VALUES (
        'movimentacao_estoque', NEW.id_movimentacao, 'INSERT', NEW.tipo_movimentacao, NOW(), NEW.id_usuario,
        CONCAT(
            'Produto:', NEW.id_produto,
            ' | Lote:', IFNULL(NEW.id_lote, 'NULL'),
            ' | Quantidade:', NEW.quantidade,
            ' | De:', IFNULL(NEW.id_endereco_origem, 'NULL'),
            ' | Para:', IFNULL(NEW.id_endereco_destino, 'NULL')
        )
    );
END;

