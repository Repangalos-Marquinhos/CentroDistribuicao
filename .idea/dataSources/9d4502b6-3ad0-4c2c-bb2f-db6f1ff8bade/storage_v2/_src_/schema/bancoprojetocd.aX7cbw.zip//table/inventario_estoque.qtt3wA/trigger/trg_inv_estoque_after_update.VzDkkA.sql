create definer = admin@`%` trigger trg_inv_estoque_after_update
    after update
    on inventario_estoque
    for each row
BEGIN
    IF NEW.quantidade <> OLD.quantidade THEN
        INSERT INTO auditoria (
            tabela, id_registro, acao, evento, data_evento, id_usuario, observacao
        ) VALUES (
            'inventario_estoque', NEW.id_inventario, 'UPDATE', 'Ajuste de estoque', NOW(), NULL,
            CONCAT(
                'De:', OLD.quantidade,
                ' Para:', NEW.quantidade,
                ' | Endereço:', NEW.id_endereco
            )
        );
    END IF;
END;

