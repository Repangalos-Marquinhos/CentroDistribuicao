create
    definer = admin@`%` procedure sp_consultar_saldo(IN p_id_produto int, IN p_id_endereco int, IN p_id_lote int,
                                                     IN p_id_unidade_arm int)
BEGIN
    SELECT quantidade, status
      FROM inventario_estoque
     WHERE id_produto = p_id_produto
       AND id_endereco = p_id_endereco
       AND (id_lote = p_id_lote OR (p_id_lote IS NULL AND id_lote IS NULL))
       AND id_unidade_arm = p_id_unidade_arm;
END;

